<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  SalesPlatform Ltd
 * The Initial Developer of the Original Code is SalesPlatform Ltd.
 * SalesPlatform vtiger CRM Russian Community: http://community.salesplatform.ru/
 * If you have any questions or comments, please email: devel@salesplatform.ru
 * All Rights Reserved.
 *************************************************************************************/

$mod_strings = Array (
'Integration' => 'Интеграция',
'SINGLE_Integration' => 'Интеграция',

'LBL_HOW_TO_USE' => 'Как использовать',

);

// SalesPlatform.ru begin SPConfiguration fix
include 'renamed.ru_ru.lang.php';
// SalesPlatform.ru end
?>
